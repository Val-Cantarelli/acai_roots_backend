package com.valdielencasarin.schedulemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchedulemanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchedulemanagementApplication.class, args);
	}

}
